package au.com.bytecode.opencsv;

public interface CSVReadProc {
	void procRow(int rowIndex, String... values);
}

